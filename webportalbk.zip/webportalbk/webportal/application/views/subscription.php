<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <i class="fa fa-users"></i> Subscription Details
      
      </h1>
    </section>
    <section class="content">
      </section></div>  
       
