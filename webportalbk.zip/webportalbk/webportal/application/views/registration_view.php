<script type="text/javascript">
function checksave(TheForm)
{
   
        if(document.getElementById('fname').value=='')
            {
                alert("Please Enter  First Name");
                TheForm.fname.focus();
                return false;
            }
        if(document.getElementById('lname').value=='')
            {
                alert("Please Enter  Last Name");
                TheForm.lname.focus();
                return false;
            }
      if(document.getElementById('code').value=='0')
      {
        alert("Please Select Mobile code");
        TheForm.code.focus();
          return false;
        }
        if(document.getElementById('mobile').value=='')
            {
                alert("Please Enter  Mobile Number");
                TheForm.mobile.focus();
                return false;
            }
             if(document.getElementById('dob').value=='')
            {
                alert("Please Enter Date of birth");
                TheForm.dob.focus();
                return false;
            }
            if(document.getElementById('country').value=='0')
            {
                alert("Please Select Country");
                TheForm.country.focus();
                return false;
            }
             if(document.getElementById('subscription').value=='0')
            {
                alert("Please Select subscription");
                TheForm.subscription.focus();
                return false;
            }
             if(document.getElementById('email').value=='')
            {
                alert("Please Enter Email");
                TheForm.email.focus();
                return false;
            }
             if(document.getElementById('password').value=='')
            {
                alert("Please Enter Password");
                TheForm.password.focus();
                return false;
            }
             if(document.getElementById('cpassword').value=='')
            {
                alert("Please Enter Confirm Password");
                TheForm.cpassword.focus();
                return false;
            }
            var pas=document.getElementById('password').value;
            var cpas=document.getElementById('cpassword').value;
            if(pas!=cpas){
                 alert("Please Password and Confirm Password are different");
                TheForm.cpassword.focus();
                return false;
            }
            
       
        TheForm.method="post";
        TheForm.submit();
        return true;
    }
</script>
 <div class="content-wrapper" style="margin-left:0px">
<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />

  </head>

  <body >
 
    <!-- Content Header (Page header) -->
     <div class="col-md-12">
                <?php
                    $this->load->helper('form');
                    $error = $this->session->flashdata('error');

                    if($error)
                    {
                ?>
                <div class="alert alert-danger alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('error'); ?>                    
                </div>
                <?php } ?>
                <?php  
                    $success = $this->session->flashdata('success');
                    if($success)
                    {
                ?>
                <div class="alert alert-success alert-dismissable">
                    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                    <?php echo $this->session->flashdata('success'); ?>
                </div>
                <?php } ?>
                
                <div class="row" >
                   <div class="col-md-2" ></div>
                    <div class="col-md-8" >
                        <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
                    </div>
                </div>
            </div>
    <div align="center">
    <section class="content-header">
      
    </section>
   
     
    <section class="content">
    
        <div class="row">
            <!-- left column -->
              <div class="col-md-2"></div>
            <div class="col-md-8">
              <!-- general form elements -->
                
                
                
                <div class="box box-primary" align="center">
                    <div class="box-header">
                  <h2>  User Registration</h2>
                    </div><!-- /.box-header -->
                    <!-- form start -->
                    
                    <form role="form" id="addUser" action="<?php echo base_url() ?>addNewUser" method="post" role="form">
                        <div class="box-body">
                            <div class="row">
                                <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="fname">First Name<sup style="color: red">*</sup></label>
                                        <input type="text" class="form-control required" id="fname" name="fname" maxlength="128">
                                    </div>
                                    
                                </div>
                                 <div class="col-md-6">                                
                                    <div class="form-group">
                                        <label for="fname">Last Name<sup style="color: red">*</sup></label>
                                        <input type="text" class="form-control required" id="lname" name="lname" maxlength="128">
                                    </div>
                                    
                                </div>

                                 <div class="col-md-2" style="padding-top: 5px;">
                                    <div class="form-group">
                                       <br>
                                        <select class="form-control required" id="code" name="code">
                                          
                                            <?php
                                            if(!empty($country))
                                            {
                                                foreach ($country as $country1)
                                                {
                                                    ?>
                                                    <option value="<?php echo $country1->mobile_code ?>"><?php echo $country1->mobile_code ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>
                                 <div class="col-md-4">
                                    <div class="form-group">
                                        <label for="mobile">Mobile Number<sup style="color: red">*</sup></label>
                                        <input type="text" class="form-control required digits" id="mobile" name="mobile" maxlength="10">
                                    </div>
                                </div>
                                 <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="mobile">Date of Birth<sup style="color: red">*</sup> </label>
                                        <input type="date"  class="form-control required digits" id="dob" name="dob" >
                                    </div>
                                </div>
                               
                                 
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="role">Country</label>
                                        <select class="form-control required" id="country" name="country">
                                          
                                            <?php
                                            if(!empty($country))
                                            {
                                                foreach ($country as $country1)
                                                {
                                                    ?>
                                                    <option value="<?php echo $country1->country_code ?>"><?php echo $country1->country_name ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div> 
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="role">Subscription Type</label>
                                        <select class="form-control required" id="subscription" name="subscription">
                                           <option value="0">Select </option>
                                            <?php
                                            if(!empty($subscription))
                                            {
                                                foreach ($subscription as $subscription1)
                                                {
                                                    ?>
                                                    <option value="<?php echo $subscription1->subscription_type_code ?>"><?php echo $subscription1->subscription_type_desc ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div> 
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="email">Email address</label>
                                        <input type="text" class="form-control required email" id="email"  name="email" maxlength="128">
                                    </div>
                                </div>
                           

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="role">Role</label>
                                        <select class="form-control required" id="role" name="role">
                                            <option value="0">Select Role</option>
                                            <?php
                                            if(!empty($roles))
                                            {
                                                foreach ($roles as $rl)
                                                {
                                                    ?>
                                                    <option value="<?php echo $rl->roleId ?>"><?php echo $rl->role ?></option>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </select>
                                    </div>
                                </div>  </div>  
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="password">Password</label>
                                        <input type="password" class="form-control required" id="password"  name="password" maxlength="10">
                                    </div>
                                </div>
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="cpassword">Confirm Password</label>
                                        <input type="password" class="form-control required equalTo" id="cpassword" name="cpassword" maxlength="10">
                                    </div>
                                </div>
                            </div>
                           
                              
                            
                        </div><!-- /.box-body -->
    
                        <div class="box-footer">
                            <input type="button" onClick="checksave(this.form);" class="btn btn-primary" value="Submit" />
                            <input type="reset" class="btn btn-info" value="Reset" />
                           <button  class="btn btn-danger"><a style="color: white;" href="<?php echo base_url() ?>login">Back</a></button> 
                          
                        </div>
                    </form>
                </div>
            </div>
          
        </div>    
    </section>
    
</div>
     <script src="<?php echo base_url(); ?>assets/js/addUser.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>assets/js/jQuery-2.1.4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
  </body>
</html>
</div>