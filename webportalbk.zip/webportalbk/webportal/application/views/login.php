<style type="text/css">
  .card1{
    font-size: 19px;
border-radius: 3px;
    margin-top: -33px;
    padding: 22px;
    color: white;
  background: linear-gradient(
    60deg,#494b86,#fb8c00);
    background-color: background: linear-gradient(60deg,#5461a3,#fb8c00c7);
    box-shadow: 0 4px 20px 0 rgb(0 0 0 / 14%), 0 7px 10px -5px rgb(255 152 0 / 40%);
}
.box{
  border-radius: 3px;
  height: 400px;
}
</style>

<script type="text/javascript">

  function newregistration()
    {
      user_login.method = "post";
      user_login.action = '<? echo base_url() ?>registration';
      user_login.submit();
    }

 $(document).onload(function () {
        Captcha();
    });
    function Captcha() {
        var alpha = new Array('a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z');
        var i;
        for (i = 0; i < 6; i++) {
            var a = alpha[Math.floor(Math.random() * alpha.length)];
            var b = alpha[Math.floor(Math.random() * alpha.length)];
            var c = alpha[Math.floor(Math.random() * alpha.length)];
            var d = alpha[Math.floor(Math.random() * alpha.length)];
            var e = alpha[Math.floor(Math.random() * alpha.length)];
            var f = alpha[Math.floor(Math.random() * alpha.length)];

        }
        var code = a + b + c + d + e + f;
        document.getElementById("mainCaptcha").innerHTML = code
    }
     function checklogin(TheForm){
        if (TheForm.txtInput.value == '') {
            alert('Please enter security code !');
            TheForm.username.focus();
            return false;
        }
        var x = document.getElementById("mainCaptcha").innerHTML;
        if (TheForm.txtInput.value != x) {
            alert('Incorrect Captcha !');
            TheForm.txtInput.focus();
            return false;
        }
        TheForm.method="post";
        TheForm.submit();
        return true;

     }
</script> 


<!DOCTYPE html>
<html>
  <head>
    <meta charset="UTF-8">
    <title>Log in</title>
    <meta content='width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no' name='viewport'>
    <link href="<?php echo base_url(); ?>assets/bootstrap/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="https://maxcdn.bootstrapcdn.com/font-awesome/4.3.0/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
    <link href="<?php echo base_url(); ?>assets/dist/css/AdminLTE.min.css" rel="stylesheet" type="text/css" />

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
  </head>
  <body class="login-page" >
    <div class="login-box">
      <div class="login-logo">
        <a href="#"><b></a>
      </div><!-- /.login-logo -->
      <div class="box login-box-body">
        <div class="card1 ">Sign In</div><br>
        <?php $this->load->helper('form'); ?>
        <div class="row">
            <div class="col-md-12">
                <?php echo validation_errors('<div class="alert alert-danger alert-dismissable">', ' <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button></div>'); ?>
            </div>
        </div>
        <?php
        $this->load->helper('form');
        $error = $this->session->flashdata('error');
        if($error)
        {
            ?>
            <div class="alert alert-danger alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $error; ?>                    
            </div>
        <?php }
        $success = $this->session->flashdata('success');
        if($success)
        {
            ?>
            <div class="alert alert-success alert-dismissable">
                <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                <?php echo $success; ?>                    
            </div>
        <?php } ?>
        
        <form action="<?php echo base_url(); ?>loginMe" method="post">
          <div class="form-group has-feedback">
            <input type="email" class="form-control" placeholder="Email" name="email" required />
            <span class="glyphicon glyphicon-envelope form-control-feedback"></span>
          </div>
          <div class="form-group has-feedback">
            <input type="password" class="form-control" placeholder="Password" name="password" required />
            <span class="glyphicon glyphicon-lock form-control-feedback"></span>
          </div>
          <div class="row">
           <div class="col-md-3"></div>
             <div class="col-md-8" align="center" style="height: 31px" >

                                                        <div class="col-md-6 col-xs-5 logcaptcha" style="color:#470eec;   font-size: 19px;padding: 1px;font-weight: bold;letter-spacing: 0.5px;"
                                                             onselectstart="return false" onpaste="return false;" onCopy="return false" onCut="return false" 
                                                             onDrag="return false" onDrop="return false" readonly
                                                             id="mainCaptcha" name="mainCaptcha"  align="left"  >

                                                        </div>
                                                        <div class="col-md-6" style="padding-right:6px">
                                                        <a  style="float: right;margin-right: 0%;margin-top:2%;" onClick="Captcha()"
                                                            id="captacha"><img src="<?php echo base_url() . 'image/refrsh.png'; ?>" tabindex="6",></a>
                                                    </div>
                                                    </div>
  <br>
                                                    <div class="col-md-12">

                                                        <input type="text"  name="txtInput" id="txtInput" maxlength="6"  placeholder="Enter code shown above" class="form-control" value="">

                                                       


                                                    </div></div>
            <div class="col-xs-12" align="right">
            <br>
              <input type="button" onclick="checklogin(this.form);" class="btn btn-primary" value="Sign In" />
              <input type="button" onclick="newregistration();" class="btn btn-primary" value="New Registration" />

            </div><!-- /.col -->
           
          </div>
        </form>
 
  
        
        
      </div><!-- /.login-box-body -->
    </div><!-- /.login-box -->

    <script src="<?php echo base_url(); ?>assets/js/jQuery-2.1.4.min.js"></script>
    <script src="<?php echo base_url(); ?>assets/bootstrap/js/bootstrap.min.js" type="text/javascript"></script>
  </body>
</html>
<form name="user_login" id="user_login">
    <input type="hidden" id="csrf_test_name" name="<?php echo $this->security->get_csrf_token_name(); ?>" value="<?php echo $this->security->get_csrf_hash(); ?>" />
</form>
<script type="text/javascript">
   $( window ).on("load", function() {
     Captcha();
});
 
</script>